package telran.spring.service;

public interface Sender {
	void send(String text, String address);
}
